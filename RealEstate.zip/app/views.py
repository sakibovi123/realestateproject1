from django.http import Http404
from django.shortcuts import render
from django.views import View
from .models import Area
from django.http import Http404

class HomeView(View):
    template_name = "home/index.html"
    def get(self, request):
        query = Area.objects.all()
        args = {
            "query": query,
        }
        return render(request, self.template_name, args)


# actions goes here 
def search_area(request):
    if request.method == "POST":
        post = request.POST
        search = post.get("search")
        query_result = Area.objects.filter(name_msa=search)
        return query_result
    else:
        return Http404

        