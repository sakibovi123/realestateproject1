from import_export import resources
from .models import *


class AreaResource(resources.ModelResource):
    class Meta:
        model = Area